// Site-specific JavaScript
window.addEventListener('DOMContentLoaded', () => {
  // Initialize kit UI components
  if (typeof window.KUI !== 'undefined') {
    window.KUI.init();
  }

  // Add custom behavior for product cards
  const productCards = document.querySelectorAll('.k-product');
  productCards.forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.style.transform = 'translateY(-5px)';
    });
    card.addEventListener('mouseleave', () => {
      card.style.transform = 'translateY(0)';
    });
  });

  // Cart functionality
  const cartButtons = document.querySelectorAll('[data-k-add]');
  cartButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      e.preventDefault();
      const id = button.dataset.id;
      const name = button.dataset.name;
      const price = button.dataset.price;
      
      // Add to localStorage cart
      let cart = JSON.parse(localStorage.getItem('cart')) || [];
      const existingItem = cart.find(item => item.id === id);
      
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cart.push({ id, name, price, quantity: 1 });
      }
      
      localStorage.setItem('cart', JSON.stringify(cart));
      
      // Update cart count
      updateCartCount();
      
      // Show toast message
      if (typeof window.KUI !== 'undefined') {
        window.KUI.say(`${name} به سبد خرید اضافه شد`);
      }
    });
  });

  // Update cart count display
  function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.querySelector('[data-k-cart-count]').textContent = totalItems;
  }

  // Initialize cart count on page load
  updateCartCount();
});