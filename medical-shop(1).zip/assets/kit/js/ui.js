/* AIResearch design kit — behaviour. No dependencies. Markup hooks: see KIT.md */
(function(){
  'use strict';
  var d=document,root=d.documentElement; root.classList.add('js');
  var $=function(s,c){return (c||d).querySelector(s)},$$=function(s,c){return Array.prototype.slice.call((c||d).querySelectorAll(s))};
  var fa=new Intl.NumberFormat('fa-IR');
  function safe(fn,fb){try{return fn()}catch(e){return fb}}
  // reveal on scroll
  var items=$$('.k-reveal');
  if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-in');io.unobserve(e.target)}})},{threshold:.12});items.forEach(function(el,i){el.style.setProperty('--i',i%6);io.observe(el)})}else items.forEach(function(el){el.classList.add('is-in')});
  // sticky nav shadow + mobile menu
  var nav=$('.k-nav');if(nav){var on=function(){nav.classList.toggle('is-scrolled',scrollY>8)};on();addEventListener('scroll',on,{passive:true})}
  var tg=$('.k-nav__toggle'),links=$('.k-nav__links');
  if(tg&&links)tg.addEventListener('click',function(){var o=links.classList.toggle('is-open');tg.setAttribute('aria-expanded',o)});
  // count-up numbers: <b data-k-count="1200">
  $$('[data-k-count]').forEach(function(el){var to=+el.dataset.kCount||0,t0=null;if(!('IntersectionObserver' in window)){el.textContent=fa.format(to);return}
    new IntersectionObserver(function(es,ob){if(!es[0].isIntersecting)return;ob.disconnect();(function step(t){t0=t0||t;var k=Math.min((t-t0)/1400,1);el.textContent=fa.format(Math.round(to*(1-Math.pow(1-k,3))));if(k<1)requestAnimationFrame(step)})(performance.now())}).observe(el)});
  // 3D tilt: <div data-k-tilt>
  if(!matchMedia('(prefers-reduced-motion: reduce)').matches&&matchMedia('(hover:hover)').matches)$$('[data-k-tilt]').forEach(function(el){
    el.addEventListener('pointermove',function(e){var r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;el.style.transform='perspective(700px) rotateY('+(x*8)+'deg) rotateX('+(-y*8)+'deg) translateY(-6px)'});
    el.addEventListener('pointerleave',function(){el.style.transform=''})});
  // theme toggle: <button data-k-theme>
  var th=safe(function(){return localStorage.getItem('k-theme')},null);if(th)root.dataset.theme=th;
  $$('[data-k-theme]').forEach(function(b){b.addEventListener('click',function(){var n=root.dataset.theme==='dark'?'light':'dark';root.dataset.theme=n;safe(function(){localStorage.setItem('k-theme',n)})})});
  // toast
  var toast;function say(msg){if(!toast){toast=d.createElement('div');toast.className='k-toast';toast.setAttribute('role','status');d.body.appendChild(toast)}toast.textContent=msg;toast.classList.add('is-show');clearTimeout(say.t);say.t=setTimeout(function(){toast.classList.remove('is-show')},2200)}
  // client-side cart (preview/UX layer). A real shop must ALSO keep the cart server-side (Django session) for checkout.
  var KEY='k-cart',cart=safe(function(){return JSON.parse(localStorage.getItem(KEY)||'[]')},[]);
  function save(){safe(function(){localStorage.setItem(KEY,JSON.stringify(cart))});paint()}
  function count(){return cart.reduce(function(n,i){return n+i.qty},0)}
  function total(){return cart.reduce(function(n,i){return n+i.qty*i.price},0)}
  var drawer=$('.k-drawer'),scrim=$('.k-scrim');
  function open(v){if(!drawer)return;drawer.classList.toggle('is-open',v);if(scrim)scrim.classList.toggle('is-open',v)}
  function paint(){
    $$('[data-k-cart-count]').forEach(function(el){el.textContent=fa.format(count())});
    $$('[data-k-cart-total]').forEach(function(el){el.textContent=fa.format(total())});
    var ul=$('.k-drawer__list');if(!ul)return;ul.innerHTML='';
    if(!cart.length){var li=d.createElement('li');li.textContent='سبد خرید خالی است.';li.style.color='var(--k-muted)';ul.appendChild(li);return}
    cart.forEach(function(it){var li=d.createElement('li');li.className='k-drawer__item';
      var n=d.createElement('b');n.textContent=it.name;var p=d.createElement('span');p.className='k-price';p.textContent=fa.format(it.price*it.qty);
      var q=d.createElement('div');q.className='k-qty';
      [['−',-1],[null,0],['+',1]].forEach(function(x){if(x[0]===null){var s=d.createElement('span');s.textContent=fa.format(it.qty);q.appendChild(s);return}var b=d.createElement('button');b.type='button';b.textContent=x[0];b.setAttribute('aria-label',x[1]>0?'افزایش':'کاهش');b.addEventListener('click',function(){it.qty+=x[1];if(it.qty<1)cart=cart.filter(function(c){return c!==it});save()});q.appendChild(b)});
      li.appendChild(n);li.appendChild(p);li.appendChild(q);ul.appendChild(li)})}
  $$('[data-k-add]').forEach(function(btn){btn.addEventListener('click',function(e){
    var id=btn.dataset.id,name=btn.dataset.name||'محصول',price=+btn.dataset.price||0;
    if(!id)return;e.preventDefault();
    var it=cart.filter(function(c){return c.id===id})[0];if(it)it.qty++;else cart.push({id:id,name:name,price:price,qty:1});
    save();say(name+' به سبد خرید اضافه شد');
    var cb=$('.k-cart-btn');if(cb){cb.classList.add('is-bump');setTimeout(function(){cb.classList.remove('is-bump')},350)}})});
  $$('[data-k-cart-open]').forEach(function(b){b.addEventListener('click',function(){open(true)})});
  $$('[data-k-cart-close]').forEach(function(b){b.addEventListener('click',function(){open(false)})});
  if(scrim)scrim.addEventListener('click',function(){open(false)});
  addEventListener('keydown',function(e){if(e.key==='Escape')open(false)});
  paint();
  window.KUI={say:say,cart:{items:function(){return cart.slice()},count:count,total:total,open:open}};
})();
